package com.lumio.cinematiclauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var lastRx = TrafficStats.getTotalRxBytes()
    @Volatile private var lastTx = TrafficStats.getTotalTxBytes()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(4, 13, 27)
        window.navigationBarColor = android.graphics.Color.rgb(4, 13, 27)

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(4, 13, 27))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) { injectApps() }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(TvBridge(), "Lumio")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        executor.scheduleAtFixedRate({
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val down = if (rx >= 0 && lastRx >= 0) (rx - lastRx).coerceAtLeast(0) * 8.0 / 1_000_000.0 else 0.0
            val up = if (tx >= 0 && lastTx >= 0) (tx - lastTx).coerceAtLeast(0) * 8.0 / 1_000_000.0 else 0.0
            lastRx = rx
            lastTx = tx
            runOnUiThread {
                if (::web.isInitialized) web.evaluateJavascript(
                    "window.updateNetwork(${String.format(java.util.Locale.US, "%.2f", down)}, ${String.format(java.util.Locale.US, "%.2f", up)})", null
                )
            }
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun injectApps() {
        val array = JSONArray()
        discoverApps().forEach { (label, pkg) ->
            array.put(JSONObject().put("label", label).put("packageName", pkg))
        }
        web.evaluateJavascript("window.setInstalledApps(${JSONObject.quote(array.toString())})", null)
    }

    private fun discoverApps(): List<Pair<String, String>> {
        val pm = packageManager
        val found = linkedMapOf<String, String>()
        val intents = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )
        intents.forEach { intent ->
            val results = if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, 0)
            }
            results.forEach { info ->
                val pkg = info.activityInfo?.packageName ?: return@forEach
                if (pkg == packageName || found.containsKey(pkg)) return@forEach
                found[pkg] = info.loadLabel(pm)?.toString() ?: pkg
            }
        }
        return found.map { it.value to it.key }.sortedBy { it.first.lowercase() }
    }

    inner class TvBridge {
        @JavascriptInterface fun launchApp(packageName: String) {
            runOnUiThread {
                try {
                    val intent = packageManager.getLeanbackLaunchIntentForPackage(packageName)
                        ?: packageManager.getLaunchIntentForPackage(packageName)
                    if (intent != null) startActivity(intent)
                    else Toast.makeText(this@MainActivity, "This app cannot be launched.", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Unable to open app.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        @JavascriptInterface fun openSettings() {
            runOnUiThread {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "Settings unavailable", Toast.LENGTH_SHORT).show() }
            }
        }
        @JavascriptInterface fun refreshApps() { runOnUiThread { injectApps() } }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        // Keep the launcher visible as the selected Home screen.
    }

    override fun onDestroy() {
        executor.shutdownNow()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
