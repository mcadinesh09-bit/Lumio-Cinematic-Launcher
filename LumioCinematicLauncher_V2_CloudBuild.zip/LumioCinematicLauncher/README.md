# Lumio Cinematic Launcher 2.0

Premium Android TV home launcher based on the approved Lumio Dashboard HTML prototype.

## Features
- Midnight-blue cinematic dashboard with colourful app cards.
- Dynamic clock, date and monthly calendar.
- Discovers installed Android TV / launcher apps and launches them.
- Live device-wide network traffic rates from Android TrafficStats (not an internet speed test).
- TV Settings shortcut and remote D-pad / OK navigation.
- Target SDK 35, Java/Kotlin 17, no ads, analytics, trackers or INTERNET permission.

## Limitations
- Android has no universal public API for third-party apps to read the active HDMI/AV input on every TV. This version does not guess the active source. An OEM-supported Lumio API would be needed.
- Network rates are device-wide traffic counters and may include background traffic.
- App artwork uses colourful category gradients; actual app icon artwork can be integrated in a later revision.
- TV manufacturers may restrict third-party Home apps or the Home-app chooser.

## Build
Use JDK 17, Android SDK Platform 35 and Gradle 8.9. Run `gradle assembleDebug`.
APK output: `app/build/outputs/apk/debug/app-debug.apk`.
