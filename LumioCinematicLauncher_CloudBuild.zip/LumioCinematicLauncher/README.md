# Lumio Cinematic Launcher

An ad-free Android TV launcher starter project for Lumio Vision 7 (2025, Android 14).

## What is included
- Native Android Activity with HOME / DEFAULT intent filter so Android TV can offer it as a Home launcher.
- Leanback + standard launcher app discovery, with package de-duplication.
- App tiles use the installed app's actual icon and label.
- Launches Leanback launch intent where available, then falls back to the standard launch intent.
- D-pad focusable app tiles, OK to open, Back stays on launcher.
- Clock, TV settings shortcut, refresh apps action.
- No ad SDK, analytics SDK, trackers, or network permissions.

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync complete. Use JDK 17 for Gradle (Android Studio's bundled JBR is suitable).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

This source bundle does not include a prebuilt APK. A working Android SDK/Gradle build environment is required to compile and verify the APK. It has not yet been tested on the physical Lumio TV.

## Install and select as Home
- Copy the debug APK to a USB drive or install with `adb install -r app-debug.apk`.
- Open the TV Home action. If Android shows a launcher chooser, choose **Lumio Cinematic**.
- If it does not appear, open Settings > Apps > Default apps > Home app (wording varies by TV firmware).

## Important compatibility notes
- Some TV manufacturers restrict third-party Home apps or hide the Home-app selector.
- Android package visibility is requested to list installed apps. The permission is used locally for app discovery only.
- The app list depends on apps exposing a launcher activity. Manufacturer/system apps that expose no launch intent cannot be launched from this UI.
- This is a first functional baseline. Confirm behavior on the actual TV before replacing the stock launcher.
