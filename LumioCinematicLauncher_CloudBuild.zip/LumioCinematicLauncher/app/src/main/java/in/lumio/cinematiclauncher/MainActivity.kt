package in.lumio.cinematiclauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TvApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 10, 18)
    private val apps = mutableListOf<TvApp>()
    private lateinit var appRow: LinearLayout
    private lateinit var timeText: TextView
    private var focusedIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildHome()
        loadApps()
        updateClock()
        timeText.post(object : Runnable {
            override fun run() {
                updateClock()
                timeText.postDelayed(this, 30_000)
            }
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun buildHome() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(24), dp(42), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(22, 35, 59), Color.rgb(13, 15, 28), bg)
            )
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text("lumio", 22f, Color.WHITE, true))
        top.addView(text("  vision", 20f, Color.LTGRAY))
        val spacer = View(this)
        top.addView(spacer, LinearLayout.LayoutParams(0, dp(1), 1f))
        timeText = text("", 17f, Color.WHITE, true)
        top.addView(timeText)
        outer.addView(top, LinearLayout.LayoutParams(-1, dp(42)))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        listOf("Watch Now", "Movies", "TV Shows", "Library").forEachIndexed { i, label ->
            val item = text(label, 14f, if (i == 0) Color.WHITE else 0xFFB7B8C4.toInt(), i == 0)
            item.setPadding(dp(12), dp(7), dp(12), dp(7))
            if (i == 0) item.background = rounded(0x33FFFFFF, 18)
            nav.addView(item)
        }
        outer.addView(nav, LinearLayout.LayoutParams(-1, dp(48)))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(20), 0, dp(8))
        }
        hero.addView(text("FEATURED TONIGHT", 11f, 0xFFD1C7FF.toInt(), true))
        val title = text("Your next\nfavourite.", 42f, Color.WHITE, true)
        title.setLineSpacing(dp(1).toFloat(), 1f)
        hero.addView(title, LinearLayout.LayoutParams(-1, dp(112)))
        val desc = text("A world of entertainment, gathered in one beautiful place.", 16f, 0xFFD0D1DB.toInt())
        hero.addView(desc, LinearLayout.LayoutParams(-1, dp(34)))
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val settings = makeButton("⚙  TV Settings") { openSettings() }
        val refresh = makeButton("↻  Refresh Apps") { loadApps() }
        actionRow.addView(settings)
        actionRow.addView(refresh, LinearLayout.LayoutParams(-2, dp(46)).apply { leftMargin = dp(12) })
        hero.addView(actionRow)
        outer.addView(hero, LinearLayout.LayoutParams(-1, 0, 1f))

        val heading = text("Your Apps", 20f, Color.WHITE, true)
        outer.addView(heading, LinearLayout.LayoutParams(-1, dp(34)))
        val hint = text("Choose an app to launch", 12f, 0xFF9FA2B2.toInt())
        outer.addView(hint, LinearLayout.LayoutParams(-1, dp(24)))

        val horizontal = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
        }
        appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(12), dp(18), dp(12))
        }
        horizontal.addView(appRow)
        outer.addView(horizontal, LinearLayout.LayoutParams(-1, dp(150)))

        val footer = text("LUMIO VISION 7  •  ANDROID TV     〈 〉 MOVE     OK SELECT     BACK HOME", 10f, 0xFF9698A8.toInt())
        outer.addView(footer, LinearLayout.LayoutParams(-1, dp(24)))
        setContentView(outer)
    }

    private fun makeButton(label: String, action: () -> Unit): TextView =
        text(label, 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(0x2EFFFFFF, 22, 0x55FFFFFF)
            isFocusable = true
            isClickable = true
            setOnClickListener { action() }
        }

    private fun loadApps() {
        apps.clear()
        val pm = packageManager
        val found = linkedMapOf<String, TvApp>()
        val categories = listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        )
        for (intent in categories) {
            val results = if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            }
            results.forEach { info ->
                val pkg = info.activityInfo?.packageName ?: return@forEach
                if (pkg == packageName || found.containsKey(pkg)) return@forEach
                val label = info.loadLabel(pm)?.toString() ?: pkg
                val icon = try { info.loadIcon(pm) } catch (_: Exception) { getDrawable(android.R.drawable.sym_def_app_icon)!! }
                found[pkg] = TvApp(label, pkg, icon)
            }
        }
        apps.addAll(found.values.sortedBy { it.label.lowercase(Locale.getDefault()) })
        renderApps()
    }

    private fun renderApps() {
        appRow.removeAllViews()
        if (apps.isEmpty()) {
            appRow.addView(text("No apps found. Press Refresh Apps.", 14f, Color.WHITE))
            return
        }
        apps.forEach { app ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(0x24FFFFFF, 20, 0x35FFFFFF)
                isFocusable = true
                isClickable = true
                setPadding(dp(10), dp(10), dp(10), dp(8))
                contentDescription = app.label
                setOnClickListener { launch(app.packageName) }
                setOnFocusChangeListener { view, hasFocus ->
                    view.background = rounded(
                        if (hasFocus) 0x55B7A7FF else 0x24FFFFFF,
                        20,
                        if (hasFocus) Color.WHITE else 0x35FFFFFF
                    )
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            card.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
            val label = text(app.label, 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            card.addView(label, LinearLayout.LayoutParams(dp(108), dp(28)))
            appRow.addView(card, LinearLayout.LayoutParams(dp(128), dp(112)).apply {
                rightMargin = dp(12)
            })
        }
        appRow.post { if (appRow.childCount > 0) appRow.getChildAt(0).requestFocus() }
    }

    private fun launch(pkg: String) {
        try {
            val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) startActivity(intent)
            else toast("This app does not expose a launch screen.")
        } catch (_: Exception) { toast("Unable to open this app.") }
    }

    private fun openSettings() {
        val intents = listOf(
            Intent("android.settings.SETTINGS"),
            Intent("android.settings.WIFI_SETTINGS")
        )
        for (i in intents) {
            try { startActivity(i); return } catch (_: Exception) { }
        }
        toast("TV Settings could not be opened.")
    }

    private fun updateClock() {
        timeText.text = SimpleDateFormat("EEE, d MMM   h:mm a", Locale.getDefault()).format(Date())
    }

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // Keep the launcher on screen when Back is pressed.
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
